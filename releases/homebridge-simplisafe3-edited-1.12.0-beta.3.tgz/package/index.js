"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _path = _interopRequireDefault(require("path"));
var _simplisafe = _interopRequireWildcard(require("./simplisafe"));
var _authManager = _interopRequireDefault(require("./lib/authManager"));
var _diagnosticLog = _interopRequireWildcard(require("./lib/diagnosticLog"));
var _alarm = _interopRequireDefault(require("./accessories/alarm"));
var _entrySensor = _interopRequireDefault(require("./accessories/entrySensor"));
var _motionSensor = _interopRequireDefault(require("./accessories/motionSensor"));
var _smokeDetector = _interopRequireDefault(require("./accessories/smokeDetector"));
var _coDetector = _interopRequireDefault(require("./accessories/coDetector"));
var _waterSensor = _interopRequireDefault(require("./accessories/waterSensor"));
var _freezeSensor = _interopRequireDefault(require("./accessories/freezeSensor"));
var _doorLock = _interopRequireDefault(require("./accessories/doorLock"));
var _camera = _interopRequireDefault(require("./accessories/camera"));
var _unreachableAccessory = _interopRequireDefault(require("./accessories/unreachableAccessory"));
function _interopRequireWildcard(e, t) { if ("function" == typeof WeakMap) var r = new WeakMap(), n = new WeakMap(); return (_interopRequireWildcard = function (e, t) { if (!t && e && e.__esModule) return e; var o, i, f = { __proto__: null, default: e }; if (null === e || "object" != typeof e && "function" != typeof e) return f; if (o = t ? n : r) { if (o.has(e)) return o.get(e); o.set(e, f); } for (const t in e) "default" !== t && {}.hasOwnProperty.call(e, t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, t)) && (i.get || i.set) ? o(f, t, i) : f[t] = e[t]); return f; })(e, t); }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Named apart from homebridge-simplisafe3 so both can be installed and run side by side
const PLUGIN_NAME = 'homebridge-simplisafe3-edited';
const PLATFORM_NAME = 'SimpliSafe 3 Edited';
// this edition is meant to run the cameras next to the original plugin, which keeps the alarm and sensors
const DEFAULT_CAMERAS_ONLY = true;
const cameraRefreshInterval = 10 * 60 * 1000; // ms, keeps camera battery and charging state current

let PLUGIN_VERSION = 'unknown';
try {
  PLUGIN_VERSION = require('./package.json').version; // package.json sits next to index.js once built
} catch (err) {/* running from source */}
let UUIDGen;
class SS3Platform {
  constructor(log, config, api) {
    log = this.keepLogsForClaude(log, config, api);
    this.log = log;
    this.name = config.name;
    // only cameras, e.g. to run them on their own bridge next to another instance with the alarm and sensors
    this.camerasOnly = config.camerasOnly !== undefined ? !!config.camerasOnly : DEFAULT_CAMERAS_ONLY;
    this.enableCameras = config.cameras || this.camerasOnly;
    this.cameraOptions = config.cameraOptions || null;
    this.debug = config.debug || false;
    this.persistAccessories = config.persistAccessories !== undefined ? config.persistAccessories : true;
    this.excludedDevices = config.excludedDevices || [];
    this.devices = [];
    this.accessories = [];
    this.api = api;
    this.cachedAccessoryConfig = [];
    this.unreachableAccessories = [];
    let refreshInterval = 15000;
    if (config.sensorRefresh) {
      refreshInterval = config.sensorRefresh * 1000;
    }
    this.snapshotDir = _path.default.join(this.api.user.storagePath(), `${PLUGIN_NAME}-snapshots`);
    this.authManager = new _authManager.default(this.api.user.storagePath(), log, this.debug);
    this.simplisafe = new _simplisafe.default(refreshInterval, this.authManager, this.api.user.storagePath(), log, this.debug);
    if (config.subscriptionId) {
      if (this.debug) this.log(`Specifying account number: ${config.subscriptionId}`);
      this.simplisafe.setDefaultSubscription(config.subscriptionId);
    }
    if (config.auth && config.auth.username && config.auth.password && !this.authManager.accountsFileExists()) {
      // this will flag authManager to try username / pw login
      this.authManager.username = config.auth.username;
      this.authManager.password = config.auth.password;
    }
    this.initialLoad = this.authManager.refreshCredentials().then(() => {
      return this.discoverSimpliSafeDevices();
    }).catch(err => {
      if (err instanceof _simplisafe.RateLimitError) {
        this.log.error('Initial load failed due to rate limiting or connectivity, trying again later');
        setTimeout(async () => {
          await this.retryBlockedAccessories();
        }, this.simplisafe.nextAttempt - Date.now());
      } else {
        this.log.error('SimpliSafe login failed with error:', err.toJSON ? err.toJSON() : err);
        this.log.error('See the plugin README for more information on authenticating with SimpliSafe.');
      }
    });
    this.api.on('didFinishLaunching', () => {
      if (this.debug) this.log(`Found ${this.cachedAccessoryConfig.length} cached accessories to be configured.`);
      if (this.debug) this.log('Attempting intial SimpliSafe credentials refresh.');
      this.initialLoad.then(() => {
        return Promise.all(this.cachedAccessoryConfig);
      }).then(() => {
        if (!this.authManager.isAuthenticated()) throw new Error('Not authenticated with SimpliSafe.');else {
          this.simplisafe.startListening();
          this.createNewPlatformAccessories();
          this.startCameraRefresh();
        }
      }).catch(err => {
        this.log.error('Initial accessories refresh failed with error:', err.toJSON ? err.toJSON() : err);
      });
    });
  }
  configureAccessory(accessory) {
    let config = new Promise((resolve, reject) => {
      this.initialLoad.then(() => {
        if (this.simplisafe.isBlocked) {
          let unreachableAccessory = new _unreachableAccessory.default(accessory, this.api);
          this.unreachableAccessories.push(unreachableAccessory);
          return resolve();
        }
        let device = this.devices.find(device => device.uuid === accessory.UUID);
        if (device) {
          if (this.debug) this.log(`Initializing device ${device.constructor.name} '${device.name ? device.name : device.uuid}' with cached accessory`);
          device.setAccessory(accessory);
          this.accessories.push(accessory);
        } else {
          if (this.debug) this.log(`Cached accessory {${accessory.UUID}} not matched to a SimpliSafe device`);
          if (!this.authManager.isAuthenticated() && accessory.services.find(s => s.UUID == this.api.hap.Service.SecuritySystem.UUID) && accessory._associatedPlugin == PLUGIN_NAME) {
            // In the case of initial auth failure instantiate the cached alarm and set fault
            const alarmAccessory = new _alarm.default('SimpliSafe 3', '000', this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(alarmAccessory);
            alarmAccessory.setAccessory(accessory);
            alarmAccessory.setFault();
          } else {
            if (this.camerasOnly && this.persistAccessories && !accessory.services.find(s => s.UUID == this.api.hap.Service.CameraRTPStreamManagement.UUID)) {
              this.log.warn(`'${accessory.displayName}' is kept but no longer updated because Cameras Only is on. Remove it from Homebridge (Settings, Remove Single Cached Accessory) if you don't need it.`);
            }
            this.removeAccessory(accessory);
          }
        }
        resolve();
      }).catch(err => {
        reject(err);
      });
    });
    this.cachedAccessoryConfig.push(config);
  }
  removeAccessory(accessory) {
    if (accessory) {
      if (!this.persistAccessories && !this.simplisafe.isBlocked) {
        if (this.debug) this.log('Removing accessory', accessory.name ?? accessory.UUID);
        this.api.unregisterPlatformAccessories(PLUGIN_NAME, PLATFORM_NAME, [accessory]);
      }
      if (this.accessories.indexOf(accessory) > -1) {
        this.accessories.splice(this.accessories.indexOf(accessory), 1);
      }
    }
  }
  createNewPlatformAccessories() {
    for (let device of this.devices) {
      let existingAccessory = this.accessories.find(acc => acc.UUID == device.uuid);
      if (!existingAccessory) {
        if (this.debug) this.log(`Initializing SS device '${device.name}' with new accessory.`);
        let accessory = device.createAccessory(); // from SimpliSafe3Accessory
        try {
          this.api.registerPlatformAccessories(PLUGIN_NAME, PLATFORM_NAME, [accessory]);
          this.accessories.push(accessory);
        } catch (err) {
          this.log.error('An error occurred while adding accessory:', err.toJSON ? err.toJSON() : err);
        }
      }
    }
  }

  // Keeps this plugin's recent log lines, without secrets, for the settings page's 'Logs for Claude' card
  keepLogsForClaude(log, config, api) {
    if (config.logsForClaude === false) return log;
    this.diagnosticLog = new _diagnosticLog.default({
      file: _path.default.join(api.user.storagePath(), _diagnosticLog.diagnosticsFilename),
      version: PLUGIN_VERSION,
      summary: () => this.cameraSummary()
    });
    api.on('shutdown', () => this.diagnosticLog.flush(true));
    return this.diagnosticLog.wrap(log);
  }
  cameraSummary() {
    const cameras = (this.devices || []).filter(device => device instanceof _camera.default);
    if (!cameras.length) return '';
    return cameras.map(camera => camera.diagnostics()).join('\n');
  }

  // Camera details, e.g. battery level, are only fetched with the alarm system, so pass on every update
  // and ask for one now and then in case nothing else does
  startCameraRefresh() {
    if (!this.enableCameras || this.cameraRefreshIntervalID) return;
    this.simplisafe.on(_simplisafe.SYSTEM_UPDATED, system => {
      try {
        this.updateCameraDetails(system.cameras);
      } catch (err) {
        this.log.error('An error occurred while updating camera details:', err);
      }
    });
    this.cameraRefreshIntervalID = setInterval(() => {
      this.simplisafe.getCameras().catch(err => {
        if (this.debug && !(err instanceof _simplisafe.RateLimitError)) this.log.error('Camera details refresh failed:', err.message || err);
      });
    }, cameraRefreshInterval);
  }
  updateCameraDetails(cameras) {
    if (!Array.isArray(cameras)) return;
    for (let device of this.devices) {
      if (!(device instanceof _camera.default)) continue;
      let details = cameras.find(camera => camera.uuid === device.id);
      if (details) device.updateCameraDetails(details);
    }
  }
  async discoverSimpliSafeDevices() {
    if (this.debug) this.log('Discovering devices from SimpliSafe');
    try {
      let subscription = await this.simplisafe.getSubscription();
      if (subscription.location.system.serial == null) throw new Error('System serial not found.');
      let uuid = UUIDGen.generate(subscription.location.system.serial);
      let alarm = this.accessories.find(acc => acc.UUID === uuid);
      if (!alarm && !this.camerasOnly) {
        const alarmAccessory = new _alarm.default('SimpliSafe 3', subscription.location.system.serial, this.log, this.debug, this.simplisafe, this.api);
        this.devices.push(alarmAccessory);
      }
      let sensors = this.camerasOnly ? [] : await this.simplisafe.getSensors();
      for (let sensor of sensors) {
        if (sensor.type == _simplisafe.SENSOR_TYPES.KEYPAD || sensor.type == _simplisafe.SENSOR_TYPES.KEYCHAIN || sensor.type == _simplisafe.SENSOR_TYPES.PANIC_BUTTON || sensor.type == _simplisafe.SENSOR_TYPES.GLASSBREAK_SENSOR || sensor.type == _simplisafe.SENSOR_TYPES.SIREN || sensor.type == _simplisafe.SENSOR_TYPES.SIREN_2 || sensor.type == _simplisafe.SENSOR_TYPES.DOORLOCK || sensor.type == _simplisafe.SENSOR_TYPES.DOORLOCK_2 || sensor.type == _simplisafe.SENSOR_TYPES.OUTDOOR_CAMERA || sensor.type == _simplisafe.SENSOR_TYPES.OUTDOOR_CAMERA_2) {
          // Ignore as no data is provided by SimpliSafe
          // Door locks are configured below, cameras with the other cameras
          continue;
        }
        let uuid = UUIDGen.generate(sensor.serial);
        let accessory = this.accessories.find(acc => acc.UUID === uuid);
        let sensorName = sensor.name;
        if (this.debug) {
          this.log(`Discovered sensor '${sensor.name}' from SimpliSafe:`, JSON.stringify(sensor));
        }
        if (sensor.serial && this.excludedDevices.includes(sensor.serial)) {
          this.log.info(`Excluding sensor with serial '${sensor.serial}'`);
          continue;
        }
        if (sensor.type == _simplisafe.SENSOR_TYPES.ENTRY_SENSOR) {
          if (!accessory) {
            sensorName = sensorName || `Entry Sensor ${sensor.serial}`;
            const sensorAccessory = new _entrySensor.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else if (sensor.type == _simplisafe.SENSOR_TYPES.CO_SENSOR) {
          if (!accessory) {
            sensorName = sensorName || `CO Detector ${sensor.serial}`;
            const sensorAccessory = new _coDetector.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else if (sensor.type == _simplisafe.SENSOR_TYPES.SMOKE_SENSOR) {
          if (!accessory) {
            sensorName = sensorName || `Smoke Detector ${sensor.serial}`;
            const sensorAccessory = new _smokeDetector.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else if (sensor.type == _simplisafe.SENSOR_TYPES.WATER_SENSOR) {
          if (!accessory) {
            sensorName = sensorName || `Water Sensor ${sensor.serial}`;
            const sensorAccessory = new _waterSensor.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else if (sensor.type == _simplisafe.SENSOR_TYPES.FREEZE_SENSOR) {
          if (!accessory) {
            sensorName = sensorName || `Freeze Sensor ${sensor.serial}`;
            const sensorAccessory = new _freezeSensor.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else if (sensor.type == _simplisafe.SENSOR_TYPES.MOTION_SENSOR) {
          sensorName = sensorName || `Motion Sensor ${sensor.serial}`;
          // Check if secret alerts are enabled
          if (sensor.setting.off == 0 || sensor.setting.home == 0 || sensor.setting.away == 0) {
            this.log.warn(`Motion Sensor '${sensorName}' requires secret alerts to be enabled in SimpliSafe before you can add it to Homebridge.`);
            continue;
          }
          if (!accessory) {
            const sensorAccessory = new _motionSensor.default(sensorName, sensor.serial, this.log, this.debug, this.simplisafe, this.api);
            this.devices.push(sensorAccessory);
          }
        } else {
          this.log.warn(`Sensor not (yet) supported: ${sensor.name}`);
          this.log.warn(sensor);
        }
      }
      let locks = this.camerasOnly ? [] : await this.simplisafe.getLocks();
      for (let lock of locks) {
        let lockName = lock.name || `Smart Lock ${lock.serial}`;
        let uuid = UUIDGen.generate(lock.serial);
        if (this.debug) {
          this.log(`Discovered door lock '${lockName}' from SimpliSafe:`, JSON.stringify(lock));
        }
        let accessory = this.accessories.find(acc => acc.UUID === uuid);
        if (!accessory) {
          const lockAccessory = new _doorLock.default(lockName, lock.serial, this.log, this.debug, this.simplisafe, this.api);
          this.devices.push(lockAccessory);
        }
      }
      if (this.enableCameras) {
        let cameras = await this.simplisafe.getCameras();
        for (let camera of cameras) {
          let cameraName = camera.cameraSettings.cameraName || `Camera ${camera.uuid}`;
          let uuid = UUIDGen.generate(camera.uuid);
          if (this.debug) {
            this.log(`Discovered camera '${cameraName}' from SimpliSafe:`, JSON.stringify(camera));
          }
          if (camera.serial && this.excludedDevices.includes(camera.serial)) {
            this.log.info(`Excluding camera with serial '${camera.serial}'`);
            continue;
          }
          let cameraAccessory = this.accessories.find(acc => acc.UUID === uuid);
          if (!cameraAccessory) {
            const cameraAccessory = new _camera.default(cameraName, camera.uuid, camera, this.cameraOptions, this.log, this.debug, this.simplisafe, this.authManager, this.api, {
              snapshotDir: this.snapshotDir
            });
            if (cameraAccessory.isUnsupported()) this.log.warn(`Detected unsupported camera ${cameraName}, some features will be disabled.`);
            this.devices.push(cameraAccessory);
          }
        }
      }
    } catch (err) {
      if (err instanceof _simplisafe.RateLimitError) {
        this.log.error('Accessory refresh failed due to rate limiting or connectivity:', err.toJSON ? err.toJSON() : err);
        this.log.info('Note: this error can also occur if you are not signed up for a SimpliSafe monitoring plan.');
      } else {
        this.log.error('An error occurred while refreshing accessories:', err.toJSON ? err.toJSON() : err);
      }
      throw err;
    }
  }
  updateAccessoriesReachability() {
    if (this.debug) this.log('Updating reacahability');
    for (let accessory of this.accessories) {
      accessory.updateReachability();
    }
  }
  async retryBlockedAccessories() {
    try {
      await this.authManager.refreshCredentials();
      if (this.debug) this.log('Recovered from 403 rate limit!');
      await this.discoverSimpliSafeDevices();
      this.cachedAccessoryConfig = [];
      for (let accessory of this.unreachableAccessories) {
        accessory.clearAccessory();
        this.configureAccessory(accessory.accessory);
      }
      await Promise.all(this.cachedAccessoryConfig);
      this.createNewPlatformAccessories();
    } catch (err) {
      if (err instanceof _simplisafe.RateLimitError) {
        this.log.error('Credentials refresh attempt failed, still rate limited');
        setTimeout(async () => {
          await this.retryBlockedAccessories();
        }, this.simplisafe.nextAttempt - Date.now());
      } else {
        this.log.error('An error occurred while refreshing credentials again:', err.toJSON ? err.toJSON() : err);
      }
    }
  }
}
const homebridge = homebridge => {
  UUIDGen = homebridge.hap.uuid;
  homebridge.registerPlatform(PLUGIN_NAME, PLATFORM_NAME, SS3Platform, true);
};
var _default = exports.default = homebridge;